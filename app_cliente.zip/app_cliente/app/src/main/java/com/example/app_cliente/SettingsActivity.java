package com.example.app_cliente;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;

public class SettingsActivity extends AppCompatActivity {

    private float k_v, k_i;

    //private final ObserverManager.OnChanged Listener = locationModel -> {
    // };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                Toast.makeText(this, "Settings selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                Intent intent_main = new Intent(SettingsActivity.this, MainActivity.class);
                intent_main.putExtra("k_v", k_v);
                intent_main.putExtra("k_i", k_i);
                // start the activity connect to the specified class
                startActivity(intent_main);
                return true;
            case R.id.item3:
                Intent intent_plot = new Intent(SettingsActivity.this, PlotActivity.class);

                // start the activity connect to the specified class
                startActivity(intent_plot);
                return true;
            case R.id.item4:
                Toast.makeText(this, "Analisis de señal selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
